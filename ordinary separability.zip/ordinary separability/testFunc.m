function y = testFunc(x)

y = sin(x(1,1)*x(1,2));
% y = x(1,1)^2*x(1,2)^2*exp(x(1,1)*x(1,2));

end