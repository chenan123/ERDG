

% clc;
clear;
Dim = 1000;
maxOptTimes = 1000;
countTimes = 1;
FEs = 0;                                                              %���ڼ�¼��Ӧ������
temp = 0;
global initial_flag bestSolution;                                                  % the global flag used in test suite

benLibrary = ['./','Optimizatiom'];
addpath(benLibrary);
for func_num = 4:18
   % set the lower and upper bound for each function
if (func_num == 1 || func_num == 4 || func_num == 7 || func_num == 8 || func_num == 9 || func_num == 12 || func_num == 13 || func_num == 14 || func_num == 17 || func_num == 18 || func_num == 19 || func_num == 20)
  lb = -100;
  ub = 100;
end
if (func_num == 2 || func_num == 5 || func_num == 10 || func_num == 15)
  lb = -5;
  ub = 5;
end
if (func_num == 3 || func_num == 6 || func_num == 11 || func_num == 16)
  lb = -32;
  ub = 32;
end

initial_flag = 0; % should set the flag to 0 for each run, each function
bestSolution = struct();
fesCounter = preOptimization(func_num,maxOptTimes);
FEs = FEs + fesCounter;

groups = {};
allDims = 1:Dim;

while ~isempty(allDims)
   relVar = allDims(1);

   while 1
       unknowVec = setdiff(allDims,relVar);
       if isempty(unknowVec)
           break;
       end
       [isNonSep,fesCounter] = judgeNonSepv2(relVar,unknowVec,func_num,lb,ub,Dim);
        FEs = FEs + fesCounter;        
       countTimes = countTimes+1;
       
       if isNonSep == 0
           break;
       end
       
       while ~isempty(unknowVec);
           underJudge = unknowVec(1);
           unknowVec(1) = [];
           [isNonSep,fesCounter] = judgeNonSepv2(relVar,underJudge,func_num,lb,ub,Dim);
           
           countTimes = countTimes+1;
           FEs = FEs + fesCounter;   
           if isNonSep == 1
               relVar = [relVar,underJudge];
           else
               continue;
           end
       end
   end
   groups = [groups,relVar];
   allDims = setdiff(allDims,relVar);
end 



seps = {};
nonseps = {};
groupNum = length(groups);
aGroup = []; 
for i =1:groupNum
   aGroup = groups{i};
   len = length(aGroup);
   if len==1
       seps = [seps,{aGroup}];
   else
       nonseps = [nonseps,{aGroup}];
   end
end

disp(func_num);
disp(countTimes);
disp(FEs);
disp(nonseps);

end        




% end





