function [result,FEs] = judgeSep(func_num,i,j,lb,ub)
FEs = 0;
global bestSolution;

result = 0;
X00 = bestSolution.varVal;
F00 = bestSolution.objVal;

for testTime = 1:20
    
    judgeR = [];
    delta = lb + (ub - lb)*rand(1);
    X10 = X00;
    X10(i) = delta;
    F10 = benchmark_func(X10,func_num);
    FEs = FEs + 1;

    delta = lb + (ub - lb)*rand(1);
    X01 = X00;
    X01(j) = delta;
    F01 = benchmark_func(X01,func_num);
    FEs = FEs + 1;

    X11 = X10;
    X11(j) = delta;
    F11 = benchmark_func(X11,func_num);
    FEs = FEs + 1;

    result1 = (F00 - F10)*(F01 - F11);
    result2 = (F00 - F01)*(F10 - F11);
    judgeR = [judgeR,result1,result2];

    delta = lb + (ub - lb)*rand(1);
    X20 = X00;
    X20(i) = delta;
    F20 = benchmark_func(X20,func_num);
    FEs = FEs + 1;

    X21 = X11;
    X21(i) = delta;
    F21 = benchmark_func(X21,func_num);
    FEs = FEs + 1;

    result1 = (F00 - F01)*(F20 - F21);
    result2 = (F00 - F20)*(F01 - F21);
    judgeR = [judgeR,result1,result2];


    result1 = (F10 - F11)*(F20 - F21);
    result2 = (F10 - F20)*(F11 - F21);
    judgeR = [judgeR,result1,result2];

    delta = lb + (ub - lb)*rand(1);
    X02 = X00;
    X02(j) = delta;
    F02 = benchmark_func(X02,func_num);
    FEs = FEs + 1;

    X12 = X11;
    X12(j) = delta;
    F12 = benchmark_func(X12,func_num);
    FEs = FEs + 1;

    result1 = (F00 - F10)*(F02 - F12);
    result2 = (F00 - F02)*(F10 - F12);
    judgeR = [judgeR,result1,result2];

    result1 = (F01 - F11)*(F02 - F12);
    result2 = (F01 - F02)*(F11 - F12);
    judgeR = [judgeR,result1,result2];

    X22 = X21;
    X22(j) = delta;
    F22 = benchmark_func(X22,func_num);
    FEs = FEs + 1;

    result1 = (F01 - F02)*(F21 - F22);
    result2 = (F01 - F21)*(F02 - F22);
    judgeR = [judgeR,result1,result2];

    result1 = (F11 - F12)*(F21 - F22);
    result2 = (F11 - F21)*(F12 - F22);
    judgeR = [judgeR,result1,result2];

    result1 = (F10 - F20)*(F12 - F22);
    result2 = (F10 - F12)*(F20 - F22);
    judgeR = [judgeR,result1,result2];


    judge = (judgeR < 0);
    if sum(judge) >0
        result = 1;
        break;
    end
end
















