
% clc;
clear;
func_num = 16;
Dims = 1000;
D = Dims; % dimensionality of benchmark functions
FEs = 0;
disp(func_num);
global initial_flag; % the global flag used in test suite
global bestSolution;


   % set the lower and upper bound for each function
if (func_num == 1 || func_num == 4 || func_num == 7 || func_num == 8 || func_num == 9 || func_num == 12 || func_num == 13 || func_num == 14 || func_num == 17 || func_num == 18 || func_num == 19 || func_num == 20)
  lb = -100;
  ub = 100;
end
if (func_num == 2 || func_num == 5 || func_num == 10 || func_num == 15)
  lb = -5;
  ub = 5;
end
if (func_num == 3 || func_num == 6 || func_num == 11 || func_num == 16)
  lb = -32;
  ub = 32;
end

initial_flag = 0;
bestSolution = struct();

fesCounter = preOptimization(func_num);
FEs = FEs + fesCounter;

DeltaMtx = zeros(D,D);

for i = 1:D-1
  for j = i+1:D
      [result,fesCounter] = judgeNonSep(i,j,func_num,lb,ub,D);
      FEs = FEs + fesCounter;
      DeltaMtx(i,j) = result;
      DeltaMtx(j,i) = result;
  end
end


interact_mtx = DeltaMtx;
%       A = growing(interact_mtx,D);
[labels , ~] = graph_connected_components(interact_mtx);
idx = labels;
for i = 1:max(labels)
  group_size = sum(labels == i);
  if (group_size==1)
      idx(labels == i) = 0;
      idx(labels>i) = idx(labels>i)-1;
  end
end
group_num = max(idx);
seps = find(idx==0);
nonseps = cell(1,group_num);
for i=1:group_num
  nonseps{i} = find(idx==i);
end
FEs_used = FEs;

disp(nonseps);


