function fesCounter= SHADE(proID, maxCycleTimes)

    global functionList bestSolution bsfValue;
    global allProblems proData;
           
    popSize = 50;
    paraMemoSize = 100;                         % the size of paraMemo which is used to store successful parameters (F&CR)
    wArchiveSize = popSize;                     % the size of wIndArchive which is used to store failing individuals    
    minGoodIndRatio = min(2.0 / popSize, 0.2);  % the minimal ratio of good individuals in pop
    maxGoodIndRatio = max(2.0 / popSize, 0.2);  % the maximal ratio of good individuals in pop

    subproNum = length(allProblems.dim);
    fesCounter = 0;
       
    optimizedTimes = 0;
    maxIterationTimes = 50;
    cycleTimes = 0;
    s = 1;
    
    while 1
        if optimizedTimes < maxIterationTimes
            optimizedTimes = optimizedTimes + 1;
        else
            s = s + 1;
            optimizedTimes = 0;
            if s > subproNum
                s = 1;
                cycleTimes = cycleTimes + 1;
                if cycleTimes > maxCycleTimes   
                    break;
                end
            end
            %Once the subproblem being evoluted is changed, evaluate the current individuals again
            tempSolutions = repmat(bestSolution.varVal, popSize, 1); 
            tempSolutions(:, allProblems.varIndex{s}) = proData.pop{s};
            tempObjVals = functionList(tempSolutions, proID);
            fesCounter = fesCounter + popSize;
            proData.popValue{s} = tempObjVals;
            [minVal, minID] = min(tempObjVals);
            if(minVal <= bestSolution.objVal)
                bestSolution.varVal = tempSolutions(minID,:);               % if a better solution is found, update bestSolution 
                bestSolution.objVal = minVal;                  %because the subproblem is unchanged, the change of bestSolution has no impact
            end
            bsfValue= [bsfValue, bestSolution.objVal];
        end
        
        subDim = allProblems.dim(s);
        subVarIndex = allProblems.varIndex{s};
        
        [~, sortIndex] = sort(proData.popValue{s}, 'ascend');
        
        gIndRatio = minGoodIndRatio + rand(popSize, 1) * (maxGoodIndRatio - minGoodIndRatio); % the ratio of good individuals
        gIndNum = ceil(popSize * gIndRatio);                        % the number of good individuals
        gIndIndex = ceil(rand(popSize, 1) .* gIndNum);              % randomly generate the indices of good individuals used for mutation
        gIndividuals = proData.pop{s}(sortIndex(gIndIndex),:);      % get good individuals specified by gIndIndex
        
        [R1, R2] = GenerateR1R2(popSize, popSize + wArchiveSize);   % randomly generate the indices of other two random individuals used for mutation
        wIndPool = [proData.pop{s}; proData.wIndArchive{s}];        % merge pop and wIndArchive for generating random individuals
        r1Individuals = proData.pop{s}(R1, :);                      % get the 1st random individual used for mutation
        r2Individuals = wIndPool(R2, :);                            %         2nd
        
        paraIndex = ceil(rand(popSize, 1) * paraMemoSize);          % randomly generate the indices of F&CR in paraMemo
        [F, CR] = GenerateFCR(proData.paraMemo{s}(paraIndex, 1), 0.1, proData.paraMemo{s}(paraIndex, 2), 0.1);  % generate F&CR
        newPop = proData.pop{s} + F(:, ones(1, subDim)) .* (gIndividuals - proData.pop{s} + ...     % mutation operator
                                                                  r1Individuals - r2Individuals); 
        isTrue = rand(popSize, subDim) > CR(:, ones(1, subDim));    % specify the indices of elements keeping the values of their parents (crossover operator)
        jRandIndex = ceil(rand(popSize, 1) * subDim);                           % essure an element is changed at least
        isTrue(sub2ind([popSize, subDim], [1: popSize]', jRandIndex)) = false;  % set the elements specified by jRandIndex to be false
        newPop(isTrue) = proData.pop{s}(isTrue);                    
        
        isTrue = newPop < proData.lBound{s};                         % correct solutions violating the bounds
        newPop(isTrue) = (proData.pop{s}(isTrue) + proData.lBound{s}(isTrue)) / 2;
        isTrue = newPop > proData.uBound{s};                         
        newPop(isTrue) = (proData.pop{s}(isTrue) + proData.uBound{s}(isTrue)) / 2;
        
        tempSolutions = repmat(bestSolution.varVal, popSize, 1);    % take the best solution as the context vector
        tempSolutions(:, subVarIndex) = newPop;         % insert the subsolutions to be evaluated
        tempObjVals = functionList(tempSolutions, proID);          % evaluate subsolutions
        newPopVal = tempObjVals;        
        fesCounter = fesCounter + popSize;
        
        sucIndex = (newPopVal < proData.popValue{s});               % get the indices of successful individuals
        if any(sucIndex)
            valDiff = zeros(popSize, 1);                
            valDiff(sucIndex) = abs(newPopVal(sucIndex) - proData.popValue{s}(sucIndex));   % get the differences between successful individuals and their parents
            nFMean = sum(valDiff(sucIndex) .* F(sucIndex) .* F(sucIndex)) / sum(valDiff(sucIndex) .* F(sucIndex));  % compute the weighted mean of F
            nCRMean = sum(valDiff(sucIndex) .* CR(sucIndex)) / sum(valDiff(sucIndex));      % compute the weighted mean of CR
            proData.paraUpdateIndex(s) = mod(proData.paraUpdateIndex(s), paraMemoSize);     % update the index of F&CR in paraMemo to be updated
            proData.paraUpdateIndex(s) = proData.paraUpdateIndex(s) + 1;                  
            proData.paraMemo{s}(proData.paraUpdateIndex(s), :) = [nFMean, nCRMean];         % update paramemo

            wArchiveUpdateIndex = ceil(rand(sum(sucIndex), 1) * wArchiveSize);              % randomly specify the indices of individuals in  wIndArchive to be updated
            proData.wIndArchive{s}(wArchiveUpdateIndex, :) = proData.pop{s}(sucIndex, :);
            proData.failedPop{s}(wArchiveUpdateIndex, :) = proData.pop{s}(sucIndex, :);
            proData.pop{s}(sucIndex, :) = newPop(sucIndex, :);      % update par & popValue
            proData.popValue{s}(sucIndex) = newPopVal(sucIndex);      
        end

        [minVal, minID] = min(tempObjVals);
        if(minVal <= bestSolution.objVal)
            bestSolution.varVal = tempSolutions(minID,:);           % if a better solution is found, update bestSolution 
            bestSolution.objVal = minVal;                   
        end
        bsfValue = [bsfValue, bestSolution.objVal];
        optimizedTimes = optimizedTimes + 1;
    end                   
end



    