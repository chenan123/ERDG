function luBound = GetBound2010(problemIndex, dim)
% get the lower and upper bounds of each variable

    if ismember(problemIndex, [1,4,7:9,12:14,17:20])
        lBound = -100 * ones(1, dim);       % lower bound of each dimension                  
        uBound = 100 * ones(1, dim);        % upper bound of each dimension                  
    elseif ismember(problemIndex, [2,5,10,15])
        lBound = -5 * ones(1, dim);             
        uBound = 5 * ones(1, dim);              
    elseif ismember(problemIndex, [3,6,11,16])
        lBound = -32 * ones(1, dim);            
        uBound = 32 * ones(1, dim);             
    else
        error(['There is no function', num2str(problemIndex), '!']);
    end
    luBound = [lBound; uBound];
end

