


function fesCounter = preOptimization(problemIndex,maxIterationTimes)

global functionList;                            % used for pointing to the functions to be optimized
global initial_flag;                            % defined by benchmark library. used for deciding whether loading the parameters of a benchmark function
global luBound;                                 % the lower and upper bounds

benchmark = 'CEC2010';                          % specify the library of benchmark functions to be solved

functionList = @benchmark_func;                 % point to benchmark function

if all(benchmark == 'CEC2010')
    dimList = 1000 * ones(1,20);                % the dimensions of CEC2010 benchmark functions
    GetBound = @GetBound2010;                   % point to GetBound function
end

if all(benchmark == 'CEC2013')
    dimList = 1000 * ones(1,15);                
    dimList([13,14]) = 905;                     % the subproblems of functions 13 and 14 have overlapping variables
    GetBound = @GetBound2013;
end

global  allProblems bestSolution;      % 3 structs used for storing the information about variable groups, subproblems and the best solution, respectively
global bsfValue                                 % store the process best solution
global proData 

popSize = 50;
initialFCR = [0.5, 0.5];                    % the initial mean values of each pair of F&CR
paraMemoSize = 100;                         % the size of paraMemo which is used to store successful parameters (F&CR)
wArchiveSize = popSize;                     % the size of wIndArchive which is used to store failing individuals    

dim = dimList(problemIndex);                % specify the dimension number
luBound = GetBound(problemIndex, dim);      % get the lower and upper bounds of each variable

initial_flag = 0;                           % tell benchmark_fun to load the parameters related with current function    

% maxIterationTimes = 1000;    
proData = struct();              
allProblems = struct();
bestSolution = struct();


allProblems.dim = dim;
allProblems.varIndex = {[1: dim]};
allProblems.isSeparable = 0;

rand('state', sum(100*clock));
bsfValue = [];
fesCounter = 0;

consumedFEs = InitializeProData(problemIndex, popSize, initialFCR, paraMemoSize, wArchiveSize,dim);
fesCounter = fesCounter + consumedFEs;

consumedFES = SHADEAll(problemIndex, maxIterationTimes);
fesCounter = fesCounter + consumedFES;  

end
