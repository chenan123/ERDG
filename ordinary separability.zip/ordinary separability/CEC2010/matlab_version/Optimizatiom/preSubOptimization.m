


function fesCounter = preSubOptimization(problemIndex)

global functionList;                            % used for pointing to the functions to be optimized
global initial_flag;                            % defined by benchmark library. used for deciding whether loading the parameters of a benchmark function
global luBound;                                 % the lower and upper bounds

benchmark = 'CEC2010';                          % specify the library of benchmark functions to be solved

functionList = @benchmark_func;                 % point to benchmark function

if all(benchmark == 'CEC2010')
    problemList = [1:20];                       % there are 20 functions in total
    dimList = 1000 * ones(1,20);                % the dimensions of CEC2010 benchmark functions
    GetBound = @GetBound2010;                   % point to GetBound function
end

if all(benchmark == 'CEC2013')
    problemList = [1:15];
    dimList = 1000 * ones(1,15);                
    dimList([13,14]) = 905;                     % the subproblems of functions 13 and 14 have overlapping variables
    GetBound = @GetBound2013;
end

global allProblems bestSolution;      % 3 structs used for storing the information about variable groups, subproblems and the best solution, respectively
global bsfValue;                                % store the process best solution
global proData;

 
proData = struct();              
allProblems = struct();
bestSolution = struct();

dim = dimList(problemIndex);                % specify the dimension number
luBound = GetBound(problemIndex, dim);      % get the lower and upper bounds of each variable

initial_flag = 0;                           % tell benchmark_fun to load the parameters related with current function    
unifiedOptimizer = @SHADE;%SaNSDE;                  % specify the optimizer to be used

allProblems.dim = [];           % dimension number
allProblems.varIndex = {};      % variable indices
allProblems.isSeparable = [];   % is separable or not

maxCycleTimes = 5;
popSize = 50;
initialFCR = [0.5, 0.5];                    % the initial mean values of each pair of F&CR
paraMemoSize = 100;                         % the size of paraMemo which is used to store successful parameters (F&CR)
wArchiveSize = popSize;                     % the size of wIndArchive which is used to store failing individuals    


randSeq = randperm(dim);
for i = 1: floor(dim / popSize)
    tempGroup = randSeq(popSize * (i - 1) + 1: popSize * i);
    allProblems.dim(i) = popSize;
    allProblems.varIndex{i} = tempGroup; 
    allProblems.isSeparable(i) = false;    
end
if popSize * i < dim
   tempGroup = randSeq(popSize * i + 1: end);
   i = i + 1;
   allProblems.dim(i) = popSize;
   allProblems.varIndex{i} = tempGroup; 
   allProblems.isSeparable(i) = false; 
end
                             %         test times           

rand('state', sum(100*clock));
bsfValue = [];                          
fesCounter = 0;

consumedFEs = InitializeProData(problemIndex, popSize, initialFCR, paraMemoSize, wArchiveSize,dim);
fesCounter = fesCounter + consumedFEs;

consumedFES = SHADE(problemIndex, maxCycleTimes);
fesCounter = fesCounter + consumedFES; 

end
      

