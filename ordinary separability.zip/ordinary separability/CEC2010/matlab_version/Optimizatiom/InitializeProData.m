function fesConsumed = InitializeProData(proID, popSize, initialFCR, paraMemoSize, wArchiveSize,dim)
% initialize process data related with each subproblem
% proID:        ID of the function to be optimized
% popSize:      the number of individuals used by SHADE.
% initialFCR:   the initial mean values of each pair of F&CR
% paraMemoSize: the size of paraMemo which is used to store successful parameters (means of F&CR)
% wArchiveSize: the size of wIndArchive which is used to store failing individuals

% fesConsumed:  the number of FEs consumed

    
    global allProblems proData luBound;
    global bestSolution functionList bsfValue;
    
    fesConsumed = 0;
    
    subproNum = length(allProblems.dim);
    proData = struct();                         % a struct used for storing process data related with each subproblem
    proData.lBound      = cell(1, subproNum);
    proData.uBound      = cell(1, subproNum);
    proData.pop         = cell(1, subproNum);
    proData.popValue    = cell(1, subproNum);   
    proData.paraMemo    = cell(1, subproNum);
    proData.wIndArchive = cell(1, subproNum);
    proData.paraUpdateIndex = ceil(rand(1, subproNum) * paraMemoSize); % initialize the index of F&CR in paraMemo to be updated   
    for g = 1: subproNum
        proData.lBound{g} = repmat(luBound(1, allProblems.varIndex{g}), popSize, 1);  
        proData.uBound{g} = repmat(luBound(2, allProblems.varIndex{g}), popSize, 1);
        proData.pop{g} = proData.lBound{g} + rand(popSize, allProblems.dim(g)) .* (proData.uBound{g} - proData.lBound{g});
        proData.paraMemo{g} = repmat(initialFCR, paraMemoSize, 1);
        proData.wIndArchive{g} = proData.lBound{g}(ones(wArchiveSize,1), :) + rand(wArchiveSize, allProblems.dim(g)) .* ...
                                (proData.uBound{g}(ones(wArchiveSize,1), :) - proData.lBound{g}(ones(wArchiveSize,1), :));  
                                                % To simplify the code, here we directly fill wIndArchive with random solutions
    end
    
    bestSolution.varVal = luBound(1,:) + rand(1, length(luBound)) .* (luBound(2,:) - luBound(1,:));
    bestSolution.objVal = functionList(bestSolution.varVal, proID);    % (re)intialize the best solution
    fesConsumed = fesConsumed + 1;                                      % for CEC2013(CEC2010) benchmark, each column(row) represents a solution
    bsfValue = [bsfValue, bestSolution.objVal];
    for g = 1: subproNum
        tempSolutions = repmat(bestSolution.varVal, popSize, 1);        % take the best solution as the context vector
        tempSolutions(:, allProblems.varIndex{g}) = proData.pop{g};     % insert the subsolutions to be evaluated
        tempObjVals = functionList(tempSolutions, proID);              % evaluate subsolutions
        proData.popValue{g} = tempObjVals;        % improved objective value
        fesConsumed = fesConsumed + popSize;  
                
        [minVal, minID] = min(tempObjVals);
        if(minVal <= bestSolution.objVal)
            bestSolution.varVal = tempSolutions(minID,:);               % if a better solution is found, update bestSolution 
            bestSolution.objVal = minVal;
        end
        bsfValue = [bsfValue, bestSolution.objVal];
    end  
     
end

        
