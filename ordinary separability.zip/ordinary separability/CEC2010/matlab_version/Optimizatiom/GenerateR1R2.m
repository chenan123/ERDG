function [R1, R2] = GenerateR1R2(popSize1, popSize2)
% generate two random vectors R1 & R2 of length popSize1
% each element of R1 is chosen from {1,2,...,popSize1} and R1(i) != i
% each element of R2 is chosen from {1,2,...,popSize2} and R2(i) != R1(i) != i
% if the condition is violated, try to regenerate R1&R2 within 1000 trials

    R0 = [1:popSize1]';    
    R1 = ceil(rand(popSize1, 1) * popSize1);                        % generate initial R1    
    isTrue = (R1 == R0);                                            % judge whether R1 is feasible
    trialTimes = 0;
    while any(isTrue) && (trialTimes < 1000)                        % if R1 is infeasible, try to modify it within 1000 trials        
        R1(isTrue) = ceil(rand(sum(isTrue), 1) * popSize1);         % modify infeasible elements in R1
        isTrue = (R1 == R0);                                        % rejudge whether R1 is feasible
        trialTimes = trialTimes + 1;
    end    
    if trialTimes >= 1000                                           % warning
        error('Cannot generate feasible R1 within 1000 trials!');
    end
     
    R2 = ceil(rand(popSize1, 1) * popSize2);                        % generate initial R2        
    isTrue = ((R2 == R0) | (R2 == R1));                             % judge whether R2 is feasible
    trialTimes = 0;
    while any(isTrue) && (trialTimes < 1000)                        % if R2 is infeasible, try to modify it within 1000 trials
        R2(isTrue) = ceil(rand(sum(isTrue), 1) * popSize2);         % modify infeasible elements in R2
        isTrue = ((R2 == R0) | (R2 == R1));                         % rejudge whether R1 is feasible
        trialTimes = trialTimes + 1;
    end
    if trialTimes >= 1000                                           % warning
        error('Cannot generate feasible R2 within 1000 trials!');
    end
end
