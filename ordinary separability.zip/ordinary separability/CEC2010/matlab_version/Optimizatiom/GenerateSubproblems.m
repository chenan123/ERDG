function [] = GenerateSubproblems(minNonsepSize, maxSepSize)
% generate subproblems according to allGroups, which stores the initial grouping structure.
% allGroups.nonseps:    a cell, each element is a vector which stores the indices of a group of nonseparable variables
%          .seps:       a vector which stores the indices of separable variables
%          .overlapNum: the number of overlapping variables between two adjacent nonseparable variable groups
%          .FEs:        fitness evaluation times consumed by the decomposition operation

% If the size of a nonseparable group is smaller than minNonsepSize, then
% combine this group with its neighbours

% If the number of separable variables is larger than maxSepSize, then allocate these variables to several subproblems,
% the maximal dimension of which is maxSepSize


% return entities: global allProblems
% allProblems.dim:          a vector which stores the dimension number of each subproblem
% allProblems.varIndex:     a cell, each element is a vector which stores the variable indices of a subproblem
% allProblems.isSeparable:  a vector, each element of which indicates whether a subproblem is separable


    global allGroups allProblems;
    allProblems.dim = [];           % dimension number
    allProblems.varIndex = {};      % variable indices
    allProblems.isSeparable = [];   % is separable or not
        
    % first generate nonseparable subproblems -----------------------------
    subproNum = 0;                                              % record the number of subproblems
    nonsepGroupNum = length(allGroups.nonsepGroups);            % get the number of nonseparable groups
    for g = 1:nonsepGroupNum
        tempVector = [];
        vecLength = 0;
        while (vecLength < minNonsepSize) && (g <= nonsepGroupNum)
            tempVector = union(tempVector, allGroups.nonsepGroups{g});  
            vecLength = length(tempVector);                     % combination operation. Here union function can remove overlapping variables
            g = g + 1;
        end      
        subproNum = subproNum + 1;
        allProblems.dim(subproNum) = vecLength;                 % dimension
        allProblems.varIndex{subproNum} = tempVector;           % the variables of this subproblem        
        allProblems.isSeparable(subproNum) = false;             % specify this is a nonseparable problem
    end
      
    % then generate separable subproblems ---------------------------------    
    sepVarNum = length(allGroups.sepGroup);                     % get the number of separable variables
    if sepVarNum > 0
        sepProNum = ceil(sepVarNum / maxSepSize);               % allocate allGroups.sepGroup into sepProNum subproblems
        sepSize1 = ceil(sepVarNum / sepProNum);                 % sepSize1 and sepSize2 make the difference among the dimensions of all problems not larger than 1
        sepSize2 = floor(sepVarNum / sepProNum);
        if sepSize1 == sepSize2                                 
            sepSizeList = sepSize1 * ones(1, sepProNum);
        else
            sepProNum1 = sepVarNum - sepProNum * sepSize2;      % the number of subproblems which have sepSize1 variables
            sepProNum2 = sepProNum - sepProNum1;                % the number of subproblems which have sepSize2 variables. Also = sepProNum * sepSize1 - sepVarNum;
            sepSizeList = [sepSize1 * ones(1,sepProNum1), sepSize2 * ones(1,sepProNum2)];
        end

        randP = randperm(sepVarNum);                            % a random sequence
        startDim = 1;
        for g = 1: sepProNum
            endDim = startDim + sepSizeList(g) - 1; 
            subproNum = subproNum + 1;
            allProblems.dim(subproNum) = sepSizeList(g);        
            allProblems.varIndex{subproNum} = allGroups.sepGroup(randP(startDim: endDim));       
            allProblems.isSeparable(subproNum) = true;          % specify this is a nonseparable problem
            startDim = endDim + 1;
        end
    end
end

