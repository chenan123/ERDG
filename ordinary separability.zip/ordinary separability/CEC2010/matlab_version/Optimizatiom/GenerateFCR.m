function [F, CR] = GenerateFCR(FMean, FSigma, CRMean, CRSigma)
% generate two random vectors F & CR
% F obeys Cauchy distribution with mean FMean and std FSigma. 
% if F > 1, set F = 1. if F <= 0, regenerate F
% CR obeys Normal distribution with mean CRMean and std CRSigma. 
% if CR > 1, set CR = 1. if CR < 0, set CR = 0

    rNum = length(FMean);                                   % get the row num;
    F = FMean + FSigma * tan(pi * (rand(rNum, 1) - 0.5));   % generate random numbers obeying Cauchy(FMean, FSigma)
    
    isTrue = (F <= 0);                                      % judge whether F <= 0
    trialTimes = 0;
    while (any(isTrue)) && (trialTimes < 1000)              % if any element in F is not greater than 0, try to regenerate it within 1000 trials
        F(isTrue) = FMean(isTrue) + FSigma * tan(pi * (rand(sum(isTrue), 1) - 0.5));
        isTrue = (F <= 0);                                  % rejudge 
        trialTimes = trialTimes + 1;
    end
    
    F(F > 1) = 1;                                           % make F <= 1
    if trialTimes >= 1000                                   % warning
        error('Cannot generate feasible F within 1000 trials!');
    end
    
    
    rNum = length(CRMean);                                  % get the row num; 
    CR = CRMean + CRSigma * randn(rNum, 1);                 % generate random numbers obeying N(CRMean, CRSigma)
    CR(CR < 0) = 0;                                         % make 0 <= CR <= 1
    CR(CR > 1) = 1;  
end
