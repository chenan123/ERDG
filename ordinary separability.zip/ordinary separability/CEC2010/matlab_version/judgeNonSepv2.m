
function [isNonSep,fesCounter] = judgeNonSepv2(VecX,VecY,func_num,lb,ub,dim)
% clc;
% clear;
% dim = 1000;
% func_num = 4;
% fileName = ['./IdealGroupResults/F',num2str(func_num,'%02d'),'.mat'];
% load(fileName);
% p = allGroups.nonsepGroups{1};
global initial_flag bestSolution allProblems;
initial_flag = 0;

% groupSize = 50;
% randSeq = randperm(dim);
% VecX = randSeq(1: groupSize);
% VecY = setdiff(1:dim,VecX);

% p = allProblems.varIndex{1};
% VecX = p;
% VecY = setdiff(1:dim,VecX);
% 
% benLibrary = ['./','Optimizatiom'];
% addpath(benLibrary);
% FEs = preOptimization(func_num);
baseVec = bestSolution.varVal;
baseVal = bestSolution.objVal;

if (func_num == 1 || func_num == 4 || func_num == 7 || func_num == 8 || func_num == 9 || func_num == 12 || func_num == 13 || func_num == 14 || func_num == 17 || func_num == 18 || func_num == 19 || func_num == 20)
  lb = -100;
  ub = 100;
end
if (func_num == 2 || func_num == 5 || func_num == 10 || func_num == 15)
  lb = -5;
  ub = 5;
end
if (func_num == 3 || func_num == 6 || func_num == 11 || func_num == 16)
  lb = -32;
  ub = 32;
end

fesCounter = 0;
testTimes = 5;
% VecX = randperm(dim,1);
% VecY = randperm(dim,1);
LB = lb*ones(1,dim);
UB = ub*ones(1,dim);

% baseVec = LB + (UB - LB).*rand(1,dim);
% baseVal = benchmark_func(baseVec,func_num);
% for k = 1:length(allGroups.nonsepGroups)
% p = allGroups.nonsepGroups{k};
% matrix = zeros(50,50);
% for i = 1 : 50
%     for j = i + 1 : 50
% VecX = p(i);
% VecY = p(j);

samplePoint = 3;

% isNonSep = 0;

for count = 1: testTimes
    isNonSep = 0;
    delta = (ub - lb)* rand(1) / 200;
    
    plusNewX = baseVec(VecX);    
    plusNewX = plusNewX + delta;    
    outBound = (plusNewX < LB(VecX));
    plusNewX(outBound) = LB(outBound);
    outBound = (plusNewX > UB(VecX));
    plusNewX(outBound) = UB(outBound);
    
    subNewX = baseVec(VecX);
    subNewX = subNewX - delta;
    outBound = (subNewX < LB(VecX));
    subNewX(outBound) = LB(outBound);
    outBound = (subNewX > UB(VecX));
    subNewX(outBound) = UB(outBound);
    
    newX = [subNewX;baseVec(VecX);plusNewX];
    
    delta = delta*100;
    
    plusNewY = baseVec(VecY);
    plusNewY = plusNewY + delta;
    outBound = (plusNewY < LB(VecY));
    plusNewY(outBound) = LB(outBound);
    outBound = (plusNewY > UB(VecY));
    plusNewY(outBound) = UB(outBound);
    
    subNewY = baseVec(VecY);
    subNewY = subNewY - delta;
    outBound = (subNewY < LB(VecY));
    subNewY(outBound) = LB(outBound);
    outBound = (subNewY > UB(VecY));
    subNewY(outBound) = UB(outBound);
    
    newY = [subNewY;baseVec(VecY);plusNewY];
    allVal = zeros(3,3);    
    temp = baseVec;
    for n = 1:samplePoint
       temp(VecY) = newY(n,:);
       for m = 1:samplePoint           
           temp(VecX) = newX(m,:);           
           tempVal = benchmark_func(temp,func_num);
           allVal(n,m) = tempVal;
       end        
    end
    fesCounter = fesCounter + 8;
    [~,sortIndexA] = sort(allVal(1,:));
    [~,sortIndexB] = sort(allVal(2,:));
    [~,sortIndexC] = sort(allVal(3,:));   
    if ~isequal(sortIndexA,sortIndexB) || ~isequal(sortIndexA,sortIndexC) ||~isequal(sortIndexB,sortIndexC)
        isNonSep = 1; 
        break;
    end
%     disp(isNonSep);
end

%     matrix(i,j) = isNonSep;
%     matrix(j,i) = isNonSep;
%     end
% end
% [labels , ~] = graph_connected_components(matrix);
% idx = labels;
% for i = 1:max(labels)
%   group_size = sum(labels == i);
%   if (group_size==1)
%       idx(labels == i) = 0;
%       idx(labels>i) = idx(labels>i)-1;
%   end
% end
% group_num = max(idx);
% seps = find(idx==0);
% nonseps = cell(1,group_num);
% for i=1:group_num
%   nonseps{i} = find(idx==i);
% end
% disp(nonseps);

% end
end
% disp(isNonSep);
% 
