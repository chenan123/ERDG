
clc;
clear;
dim = 1000;


global initial_flag bestSolution;
for func_num = 1:20;
if (func_num == 1 || func_num == 4 || func_num == 7 || func_num == 8 || func_num == 9 || func_num == 12 || func_num == 13 || func_num == 14 || func_num == 17 || func_num == 18 || func_num == 19 || func_num == 20)
  lb = -100;
  ub = 100;
end
if (func_num == 2 || func_num == 5 || func_num == 10 || func_num == 15)
  lb = -5;
  ub = 5;
end
if (func_num == 3 || func_num == 6 || func_num == 11 || func_num == 16)
  lb = -32;
  ub = 32;
end
% i = 1;
% j = 2;
FEs = 0;
isSep = 1;
i = randperm(dim,1);
j = randperm(dim,1);
fesCounter = preOptimization(func_num);
FEs = FEs + fesCounter;



for testTime = 1:20
    
initial_flag = 0;
% X00 = lb + (ub - lb)*rand(1,1000);
X00 = bestSolution.varVal;
F00 = benchmark_func(X00,func_num);
% FEs = FEs + 1;

delta = lb + (ub - lb)*rand(1);
X10 = X00;
X10(i) = delta;
F10 = benchmark_func(X10,func_num);
FEs = FEs + 1;

delta = lb + (ub - lb)*rand(1);
X01 = X00;
X01(j) = delta;
F01 = benchmark_func(X01,func_num);
FEs = FEs + 1;

X11 = X10;
X11(j) = delta;
F11 = benchmark_func(X11,func_num);
FEs = FEs + 1;

result1 = (F00 - F10)*(F01 - F11);
result2 = (F00 - F01)*(F10 - F11);

if result1<0 || result2<0
   isSep = 0;
   break;
end

delta = lb + (ub - lb)*rand(1);
X20 = X00;
X20(i) = delta;
F20 = benchmark_func(X20,func_num);
FEs = FEs + 1;

X21 = X11;
X21(i) = delta;
F21 = benchmark_func(X21,func_num);
FEs = FEs + 1;

result1 = (F00 - F01)*(F20 - F21);
result2 = (F00 - F20)*(F01 - F21);

if result1<0 || result2<0
   isSep = 0;
   break;
end

result1 = (F10 - F11)*(F20 - F21);
result2 = (F10 - F20)*(F11 - F21);
if result1<0 || result2<0
   isSep = 0;
   break;
end

delta = lb + (ub - lb)*rand(1);
X02 = X00;
X02(j) = delta;
F02 = benchmark_func(X02,func_num);
FEs = FEs + 1;

X12 = X11;
X12(j) = delta;
F12 = benchmark_func(X12,func_num);
FEs = FEs + 1;

result1 = (F00 - F10)*(F02 - F12);
result2 = (F00 - F02)*(F10 - F12);
if result1<0 || result2<0
   isSep = 0;
   break;
end

result1 = (F01 - F11)*(F02 - F12);
result2 = (F01 - F02)*(F11 - F12);
if result1<0 || result2<0
   isSep = 0;
   break;
end

X22 = X21;
X22(j) = delta;
F22 = benchmark_func(X22,func_num);
FEs = FEs + 1;

result1 = (F01 - F02)*(F21 - F22);
result2 = (F01 - F21)*(F02 - F22);
if result1<0 || result2<0
   isSep = 0;
   break;
end

result1 = (F11 - F12)*(F21 - F22);
result2 = (F11 - F21)*(F12 - F22);
if result1<0 || result2<0
   isSep = 0;
   break;
end

result1 = (F10 - F20)*(F12 - F22);
result2 = (F10 - F12)*(F20 - F22);
if result1<0 || result2<0
   isSep = 0;
   break;
end
end



if isSep == 0
    disp('nonseparable');
else
    disp('separable');
end

end















