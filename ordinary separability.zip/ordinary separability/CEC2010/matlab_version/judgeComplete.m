


dim = 1000;
benLibrary = ['./','Optimizatiom'];
addpath(benLibrary);

global initial_flag bestSolution;
for func_num = 3;
    
if (func_num == 1 || func_num == 4 || func_num == 7 || func_num == 8 || func_num == 9 || func_num == 12 || func_num == 13 || func_num == 14 || func_num == 17 || func_num == 18 || func_num == 19 || func_num == 20)
  lb = -100;
  ub = 100;
end
if (func_num == 2 || func_num == 5 || func_num == 10 || func_num == 15)
  lb = -5;
  ub = 5;
end
if (func_num == 3 || func_num == 6 || func_num == 11 || func_num == 16)
  lb = -32;
  ub = 32;
end

FEs = 0;
sampleNum = 10;


initial_flag = 0;
bestSolution = struct();
fesCounter = preOptimization(func_num);
% FEs = FEs + fesCounter;
% 
% X00 = bestSolution.varVal;
% F00 = bestSolution.objVal;
labelPoint = zeros(1,sampleNum);
labelSeq = zeros(1,sampleNum);
for i = 1:sampleNum
    randPointA = randperm(dim,1);
    randPointB = randperm(dim,1);
    while randPointA == randPointB
       randPointB = randperm(dim,1);
    end
    [isNonSep,fesCounter] = judgeNonSep(randPointA,randPointB,func_num,lb,ub,dim);
    FEs = FEs + fesCounter;
    labelPoint(i) = isNonSep;   
end

for i = 1:sampleNum
    
    randSeq = randperm(dim);
    randSeqA = randSeq(1:ceil(dim / 2));
    randSeqB = randSeq(ceil(dim / 2)+1:end);   
    [isNonSep,fesCounter] = judgeNonSep(randSeqA,randSeqB,func_num,lb,ub,dim);
    FEs = FEs + fesCounter;
    labelSeq(i) = isNonSep;
    
end
if ~any(labelPoint) && ~any(labelSeq)
    disp([num2str(func_num),':fully separable']);
elseif all(labelPoint) && all(labelSeq)
    disp([num2str(func_num),':fully nonseparable']);
else
    disp([num2str(func_num),':partially separable']);   
end
end












